README:
DEFAULT PASSWORD OF ADMIN: admin

The config file is located in inc/inc.php


---------------------------------------------------------------------------
Telegram Submit Data
Add your token & chat_id into the inc.php file and set up the $telegram variable equal to 1 instead of 0.
---------------------------------------------------------------------------
Country Block:
To enable the country filter the value of the variable $country_check should be equal to 1
You can add countries or remove by editing the $countries_allowed variable
I highly suggest to keep this option enabled
---------------------------------------------------------------------------
Telegram:
To receive the data(*notification for live panel) on your telegram set up the $telegram variable equal to 1 and update the $token and $chatID variables with your data
---------------------------------------------------------------------------
Change Path:
The page at the moment is located under the "es" folder, to change this folder name you first need to update the variable $source_control located in the inc/inc.php file. Then rename the app folder to match the same value as the variable.
---------------------------------------------------------------------------
To change admin password go to /es/admin/inc/inc.php LINE 7

---------------------------------------------------------------------------
To access admin panel it will always be yourdomain.com (https://yourdomain.com/) + the path to the panel like:

If your domain is test.com (https://test.com/) and you uploaded in public_html

then your admin link will be:
test.com/es/admin/login.php (https://test.com/es/admin/login.php)
password: admin