<?php
ini_set('display_errors', false);

// Create langs directory if it doesn't exist
if (!file_exists('langs')) {
    mkdir('langs', 0777, true);
}

if (strpos(UserInfo::get_ip(), ",") !== false) {
    $rawIP = explode(",", UserInfo::get_ip());
    $ip = $rawIP[0];
} else {
    $ip = UserInfo::get_ip();
}
$location = UserInfo::get_location($ip);

// Get language based on country code, default to English if not found
$countryCode = strtolower($location);

// Define country-language mappings
$countryLanguages = [
    // Bulgarian
    'bg' => ['bg'],
    // Czech
    'cz' => ['cs'],
    // German speaking
    'de' => ['de'],
    'at' => ['de'],
    'ch' => ['de'],
    // Greek
    'gr' => ['el'],
    'cy' => ['el'],
    // English speaking
    'gb' => ['en'],
    'us' => ['en'],
    'ca' => ['en'],
    'au' => ['en'],
    'nz' => ['en'],
    'ie' => ['en'],
    // Spanish speaking
    'es' => ['es'],
    'mx' => ['es'],
    'ar' => ['es'],
    'co' => ['es'],
    'pe' => ['es'],
    'cl' => ['es'],
    've' => ['es'],
    // French speaking
    'fr' => ['fr'],
    'be' => ['fr'],
    'ch' => ['fr'],
    'lu' => ['fr'],
    // Hungarian
    'hu' => ['hu'],
    // Italian
    'it' => ['it'],
    'sm' => ['it'],
    'va' => ['it'],
    // Dutch
    'nl' => ['nl'],
    'be' => ['nl'],
    'sr' => ['nl'],
    // Polish
    'pl' => ['pl'],
    // Portuguese
    'pt' => ['pt'],
    'br' => ['pt'],
    'ao' => ['pt'],
    'mz' => ['pt'],
    // Romanian
    'ro' => ['ro'],
    'md' => ['ro'],
    // Russian
    'ru' => ['ru'],
    'by' => ['ru'],
    'kz' => ['ru'],
    // Serbian
    'rs' => ['sr'],
    'ba' => ['sr'],
    'me' => ['sr'],
    // Swedish
    'se' => ['sv'],
    // Turkish
    'tr' => ['tr'],
    'cy' => ['tr'],
    // Ukrainian
    'ua' => ['uk']
];

// Get language based on country code, default to English if not found
$lang = isset($countryLanguages[$countryCode]) ? $countryLanguages[$countryCode][0] : 'en';

// Define supported languages from language files
$supportedLanguages = [
    'bg', // Bulgarian
    'cs', // Czech
    'de', // German
    'el', // Greek
    'en', // English
    'es', // Spanish
    'fr', // French
    'hu', // Hungarian
    'it', // Italian
    'nl', // Dutch
    'pl', // Polish
    'pt', // Portuguese
    'ro', // Romanian
    'ru', // Russian
    'sr', // Serbian
    'sv', // Swedish
    'tr', // Turkish
    'uk'  // Ukrainian
];


function startTranslation() {
    ob_start();
}

function endTranslation() {
    $content = ob_get_clean();
    global $lang;

    // Load language JSON files
    $translations = [];
    $langFile = "langs/$lang.json";
    $defaultFile = "langs/en.json";

    if (file_exists($langFile)) {
        $translations = json_decode(file_get_contents($langFile), true);
    }

    // Load default English translations as fallback
    $defaultTranslations = [];
    if (file_exists($defaultFile)) {
        $defaultTranslations = json_decode(file_get_contents($defaultFile), true);
    }

    // Create DOM to parse HTML
    $dom = new DOMDocument();
    $dom->encoding = 'UTF-8';
    $dom->preserveWhiteSpace = true;
    $dom->formatOutput = false;
    libxml_use_internal_errors(true);
    @$dom->loadHTML(mb_convert_encoding($content, 'HTML-ENTITIES', 'UTF-8'), LIBXML_HTML_NODEFDTD);
    libxml_clear_errors();

    $xpath = new DOMXPath($dom);
    $textNodes = $xpath->query('//text()[not(ancestor::style) and not(ancestor::script)]');

    // Replace text nodes with translations
    foreach ($textNodes as $node) {
        $text = trim($node->nodeValue);
        if (!empty($text)) {
            // Check language translations first, fallback to default English
            if (isset($translations[$text])) {
                $node->nodeValue = $translations[$text];
            } elseif (isset($defaultTranslations[$text])) {
                $node->nodeValue = $defaultTranslations[$text];
            }
        }
    }

    echo $dom->saveHTML();
}

/*
Usage in other files:
include 'inc/translate.php';

startTranslation();
// Your HTML content here
endTranslation();
*/
?>