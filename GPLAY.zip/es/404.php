<?php

echo "Maintenance. Try again later, please!";
?>

