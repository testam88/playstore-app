<?php
ini_set('display_errors', false);
session_start();

require_once 'inc/config.php';

require_once 'inc/mysql.php';

$clicks = count(file('../../secrets/approved_visitor.txt'));

$actual_link = str_replace("index.php?page=home", "", (empty($_SERVER['HTTPS']) ? 'http' : 'https') . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]");

if (isset($_SESSION['logged'])) {
	if (isset($_GET['page'])) {
		if ($_GET['page'] == 'home') {
      
			header('Location: generate_link.php');
      exit;
		} elseif ($_GET['page'] == 'logout') {
			session_destroy();
			header('Location: login.php');
			exit;
		} 
	} else {
		header('Location: index.php?page=home');
		exit;
	}
} else {
	header('Location: login.php');
	exit;
}


?>
