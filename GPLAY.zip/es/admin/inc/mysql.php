<?php
ini_set('display_errors', false);

$mysql = array();

$mysql['connection'] = new PDO("sqlite:".__DIR__."/49c153c2b1dee2c29b6eaf4457f1c9f2.db");








function getRow($query) {

    global $mysql;

    $data_query = $mysql['connection']->query($query);
    $data = $data_query->fetch(PDO::FETCH_ASSOC);
    return $data;

}


function getAll($query) {

    global $mysql;



    $data = array();
    $data_query = $mysql['connection']->query($query);
  
   

        while ($data_fetch = $data_query->fetch(PDO::FETCH_ASSOC)) {
            $data[] = $data_fetch;
        }

    return $data;

}



function getOne($query) {

    global $mysql;


  
    $data_query = $mysql['connection']->query($query);
    $data =  $data_query->fetch(PDO::FETCH_ASSOC);


    return reset($data);

}

function execute($query) {

    global $mysql;
    
    
    $data_query = $mysql['connection']->prepare($query);
   
    $data_query->execute();
   
}

?>
