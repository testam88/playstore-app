<?php
ini_set('display_errors', false);




$config_password = 'Dante32!'; // Admin panel password

