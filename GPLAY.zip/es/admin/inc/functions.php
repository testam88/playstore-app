<?php

function telegram( $messaggio, $token, $chatID) {

 
    $data = [
        'text' => $messaggio,
        'chat_id' => $chatID
    ];
    
    
    file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
    
    
    }