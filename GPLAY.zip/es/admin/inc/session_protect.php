<?php

if (!isset($_SESSION['uniqueid'])) {
    header('Location: https://google.com');
    exit;
}