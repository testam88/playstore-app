<?php
session_start();
$customer_id = uniqid();

$colors = [
    '#FF5733', '#33FF57', '#5733FF', '#FF5733', '#33FF57', '#5733FF',
    '#FF5733', '#33FF57', '#5733FF', '#FF5733', '#33FF57', '#5733FF',
    '#FF5733', '#33FF57', '#5733FF', '#FF5733', '#33FF57', '#5733FF',
    '#FF5733', '#33FF57', '#5733FF', '#FF5733', '#33FF57', '#5733FF',
    '#FF5733', '#33FF57', '#5733FF', '#FF5733', '#33FF57', '#5733FF',
    '#FF5733', '#33FF57', '#5733FF', '#FF5733', '#33FF57', '#5733FF',
    '#FF5733', '#33FF57', '#5733FF', '#FF5733', '#33FF57', '#5733FF',
    '#FF5733', '#33FF57', '#5733FF', '#FF5733', '#33FF57', '#5733FF',
    '#FF5733', '#33FF57', '#5733FF', '#FF5733', '#33FF57', '#5733FF'
];

$messages = [
    'Welcome to our website!',
    'Discover amazing products.',
    'Sign up for exclusive offers.',
    'Join our community today!',
    'Explore the future of technology.',
    'Unlock your full potential.',
    'Start your journey with us.',
    'Innovation at your fingertips.',
    'Get ready for a great experience.',
    'Experience excellence with us.',
    'The future is here, join us now.',
    'Unleash your creativity with us.',
    'Your adventure begins here.',
    'Elevate your life with our services.',
    'Stay connected with the world.',
    'Transform your dreams into reality.',
    'Your success is our priority.',
    'Join us and thrive!',
    'Experience the best with us.',
    'Start a new chapter with us.',
    'Your destination for success.',
    'Welcome to a world of possibilities.',
    'Your journey starts today.',
    'Dive into a world of opportunities.',
    'The adventure begins now.',
    'Discover endless possibilities.',
    'Unleash your potential with us.',
    'Experience excellence every day.',
    'The future is bright, join us!',
    'Innovation for a better tomorrow.',
    'Your success story starts here.',
    'Join us on this exciting journey.',
    'Unlock your true potential.',
    'Welcome to a world of innovation.',
    'Experience the future with us.',
    'Your dreams, our commitment.',
    'Start something incredible with us.',
    'Connect with your dreams here.',
    'Unleash your inner genius.',
    'Your journey to success begins now.',
    'Be a part of something amazing.',
    'Transform your world with us.',
    'The future is yours to create.',
    'Embrace a world of opportunities.',
    'Discover a world of endless horizons.',
    'Welcome to a brighter future.',
    'Explore, innovate, succeed!'
];

$selected_color = $colors[array_rand($colors)];
$selected_message = $messages[array_rand($messages)];
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title><?php echo $selected_message; ?></title>
    <style>
        body {
            background-color: <?php echo $selected_color; ?>;
            text-align: center;
            font-size: 24px;
            color: #fff;
            margin: 0;
            padding: 0;
            font-family: Arial, Helvetica, sans-serif;
        }

        .container {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .heading {
            font-size: 36px;
            margin-bottom: 20px;
        }

        .cta {
            font-size: 18px;
            margin-top: 20px;
        }

        .customer-id {
            font-size: 14px;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="heading"><?php echo $selected_message; ?></div>
        <div class="cta">
<?php
		$messages = [
                'Explore our exciting offerings and join us today!',
                'Join our community and experience the future!',
                'Unlock your potential with us today!',
                'Discover innovation and join us now!',
                'Start your journey to success today!',
                'Experience excellence with our services!',
                'Welcome to a world of endless opportunities!',
                'Join us for a brighter tomorrow!',
                'Embrace the future with us!',
                'Experience a world of innovation!',
                'Unlock your true potential with us!',
                'Discover a world of endless horizons!',
                'Join us on a journey of success!',
                'Innovation for a better tomorrow!',
                'Explore, innovate, succeed!',
                'Your dreams, our commitment!',
                'Start something incredible with us!',
                'Connect with your dreams here!',
                'Unleash your inner genius!',
                'Your journey to success begins now!',
                'Be a part of something amazing!',
                'Transform your world with us!',
                'The future is yours to create!',
                'Embrace a world of opportunities!',
                'Discover a world of endless horizons!',
                'Welcome to a brighter future!',
                'Experience excellence every day!',
                'The future is bright, join us!',
                'Innovation at your fingertips!',
                'Get ready for a great experience!',
                'Join us and thrive!',
                'Experience the best with us!',
                'Start a new chapter with us!',
                'Your destination for success!',
                'Your journey starts today!',
                'Dive into a world of opportunities!',
                'The adventure begins now!',
                'Discover endless possibilities!',
                'Unleash your potential with us!',
                'Your success is our priority!',
                'Experience the future with us!',
                'Your adventure begins here!',
                'Elevate your life with our services!',
                'Stay connected with the world!',
                'Transform your dreams into reality!',
                'Welcome to our website!',
                'Discover amazing products!',
                'Sign up for exclusive offers!',
                'Join our community today!',
                'Explore the future of technology!',
                'Unlock your full potential!',
                'Start your journey with us!'
            ];

            echo $messages[array_rand($messages)];
            ?></div>
        <div class="customer-id">Your unique customer ID: <?php echo $customer_id; ?></div>
    </div>
</body>
</html>
